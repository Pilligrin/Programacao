﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testedrop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //definição de variáveis globais dentro do Form1, contudo locais para outros Forms
        SqlConnection conexao;
        SqlCommand comando;
        string instrucao_executa;
        string instrucao_preenche;
        SqlDataAdapter consulta;
        DataTable tabela;
        ListViewItem item_list_view;
        int n = 7;
        string instrucao_filtro = "SELECT mar.descr_marca 'marca' , mo.descr_modelo 'modelo', de.descricao 'descrição', e.num_patrimonio 'nº patr.', e.serialNum 'Serial Number', e.cod_sap 'SAP', l.descr_local 'Lab.', st.descr_status 'Status'" +
                " FROM equipamentos e"
                + " INNER JOIN marcas_equip mar ON mar.cod_marca = e.cod_marca"
                + " INNER JOIN modelos_equip mo ON mo.cod_modelo = e.cod_modelo"
                + " INNER JOIN descricoes_equip de ON de.cod_descr = e.cod_descr"
                + " INNER JOIN status_equip st ON st.cod_status= e.cod_status"
                + " INNER JOIN locais l ON l.cod_local = e.cod_local";



        //Método para realizar a conexão do SQL com o Visual Studio
        private void conecta()
        {
            //Por favor, altere o data source para alt
            conexao = new SqlConnection("Data source = localhost; initial catalog = master; User ID= sa; Password = 123456;");   
        }

        private void executa()
        {
            conexao.Open();
            comando = new SqlCommand(instrucao_executa, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
        }

        private void preenche()
        {
            consulta = new SqlDataAdapter(instrucao_preenche, conexao);
            tabela = new DataTable();
            consulta.Fill(tabela);
        }

        private void atualiza()
        {
            conecta();

            

            preenche();

            //realiza a limpeza do listview
            lv_equipamentos.Items.Clear();
            lv_equipamentos.Columns.Clear();

            for (int i = 0; i <= n; i++)//adiciona todas as colunas necessárias
            {
                lv_equipamentos.Columns.Add(tabela.Columns[i].ColumnName);
            }



            foreach (DataRow linha in tabela.Rows)//executa para cada linha uma adição aos itens do listview, com a DaTable
            {
                item_list_view = new ListViewItem(linha[0].ToString());

                for (int j = 1; j <= n; j++)//for para colocar todos os elementos dentro do item da list view
                {
                    item_list_view.SubItems.Add(linha[j].ToString());
                }
                lv_equipamentos.Items.Add(item_list_view);//adiciona novo item à list View
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            conecta();
            instrucao_executa = "INSERT INTO equipamentos VALUES({0}, {1}, {2}, {3}, '{4}', {5}, {6}, {7});";
            instrucao_executa = string.Format(instrucao_executa, cbb_grava_marca.SelectedValue, cbb_grava_modelo.SelectedValue,
                cbb_descricao_grava.SelectedValue, txb_grava_n_pat.Text, txb_grava_serial_number.Text,
                txb_grava_sap.Text, comboBox4.SelectedValue, comboBox3.SelectedValue);

            MessageBox.Show(instrucao_executa);

            executa();

        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            instrucao_preenche = instrucao_filtro;
            atualiza();
        }

        private void btn_filtro_Click(object sender, EventArgs e)
        {
            
            instrucao_preenche = instrucao_filtro + " WHERE de.descricao LIKE '%{0}%';";
            instrucao_preenche = string.Format(instrucao_preenche, txb_filtro_descricao.Text);
            atualiza();
        }

      
        private void cbb_grava_marca_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //método utilizado para preencher o ComboBox respectivo
        private void edita_cbb(string instrucao, string display, string value, ref ComboBox obj)
        {
            conecta();
            instrucao_preenche = instrucao;
            preenche();
            //Faz a consulta e tem um DataTable
            obj.DataSource = tabela;
            obj.DisplayMember = display;
            obj.ValueMember = value;

        }

        

        private void cbb_grava_marca_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM marcas_equip;", "descr_marca", "cod_marca", ref cbb_grava_marca);
        }

        private void cbb_grava_modelo_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM modelos_equip;", "descr_modelo", "cod_modelo", ref cbb_grava_modelo);
        }

        private void lv_equipamentos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txb_grava_n_pat_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbb_descricao_grava_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM descricoes_equip;", "descricao", "cod_descr", ref cbb_descricao_grava);
        }

        private void comboBox4_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT cod_local, descr_local FROM locais;", "descr_local", "cod_local", ref comboBox4);
        }

        private void comboBox3_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM status_equip;", "descr_status", "cod_status", ref comboBox3);
        }
    }
}
