﻿namespace testedrop
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lv_equipamentos = new System.Windows.Forms.ListView();
            this.btn_atualizar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cbb_filtro_cod = new System.Windows.Forms.ComboBox();
            this.txb_filtro_sap = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_filtro_descricao = new System.Windows.Forms.TextBox();
            this.txb_filtro_serial_number = new System.Windows.Forms.TextBox();
            this.txb_filtro_n_pat = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_filtro = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.txb_grava_sap = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.cbb_grava_marca = new System.Windows.Forms.ComboBox();
            this.cbb_grava_modelo = new System.Windows.Forms.ComboBox();
            this.txb_grava_n_pat = new System.Windows.Forms.TextBox();
            this.txb_grava_serial_number = new System.Windows.Forms.TextBox();
            this.lbl_marca = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.cbb_descricao_grava = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lv_equipamentos, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_atualizar, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1100, 681);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lv_equipamentos
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.lv_equipamentos, 2);
            this.lv_equipamentos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_equipamentos.ForeColor = System.Drawing.Color.Black;
            this.lv_equipamentos.HideSelection = false;
            this.lv_equipamentos.Location = new System.Drawing.Point(3, 53);
            this.lv_equipamentos.Name = "lv_equipamentos";
            this.lv_equipamentos.Size = new System.Drawing.Size(1094, 284);
            this.lv_equipamentos.TabIndex = 0;
            this.lv_equipamentos.UseCompatibleStateImageBehavior = false;
            this.lv_equipamentos.View = System.Windows.Forms.View.Details;
            this.lv_equipamentos.SelectedIndexChanged += new System.EventHandler(this.lv_equipamentos_SelectedIndexChanged);
            // 
            // btn_atualizar
            // 
            this.btn_atualizar.BackColor = System.Drawing.Color.DarkBlue;
            this.tableLayoutPanel1.SetColumnSpan(this.btn_atualizar, 2);
            this.btn_atualizar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_atualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_atualizar.ForeColor = System.Drawing.Color.Gold;
            this.btn_atualizar.Location = new System.Drawing.Point(3, 343);
            this.btn_atualizar.Name = "btn_atualizar";
            this.btn_atualizar.Size = new System.Drawing.Size(1094, 44);
            this.btn_atualizar.TabIndex = 1;
            this.btn_atualizar.Text = "Atualizar Lista";
            this.btn_atualizar.UseVisualStyleBackColor = false;
            this.btn_atualizar.Click += new System.EventHandler(this.btn_atualizar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Navy;
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Gold;
            this.groupBox1.Location = new System.Drawing.Point(3, 393);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(544, 285);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtro";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.Controls.Add(this.button4, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.button3, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.button2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.button1, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.cbb_filtro_cod, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_sap, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_descricao, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_serial_number, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_n_pat, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn_filtro, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(538, 255);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // cbb_filtro_cod
            // 
            this.cbb_filtro_cod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_filtro_cod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_filtro_cod.ForeColor = System.Drawing.Color.Black;
            this.cbb_filtro_cod.FormattingEnabled = true;
            this.cbb_filtro_cod.Location = new System.Drawing.Point(182, 3);
            this.cbb_filtro_cod.Name = "cbb_filtro_cod";
            this.cbb_filtro_cod.Size = new System.Drawing.Size(173, 24);
            this.cbb_filtro_cod.TabIndex = 27;
            // 
            // txb_filtro_sap
            // 
            this.txb_filtro_sap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_sap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_sap.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_sap.Location = new System.Drawing.Point(182, 207);
            this.txb_filtro_sap.Multiline = true;
            this.txb_filtro_sap.Name = "txb_filtro_sap";
            this.txb_filtro_sap.Size = new System.Drawing.Size(173, 45);
            this.txb_filtro_sap.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 204);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(173, 51);
            this.label12.TabIndex = 24;
            this.label12.Text = "Código SAP";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 51);
            this.label6.TabIndex = 21;
            this.label6.Text = "Nº Patrimonio";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 51);
            this.label7.TabIndex = 20;
            this.label7.Text = "Descrição";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txb_filtro_descricao
            // 
            this.txb_filtro_descricao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_descricao.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_descricao.Location = new System.Drawing.Point(182, 54);
            this.txb_filtro_descricao.Multiline = true;
            this.txb_filtro_descricao.Name = "txb_filtro_descricao";
            this.txb_filtro_descricao.Size = new System.Drawing.Size(173, 45);
            this.txb_filtro_descricao.TabIndex = 15;
            // 
            // txb_filtro_serial_number
            // 
            this.txb_filtro_serial_number.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_serial_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_serial_number.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_serial_number.Location = new System.Drawing.Point(182, 156);
            this.txb_filtro_serial_number.Multiline = true;
            this.txb_filtro_serial_number.Name = "txb_filtro_serial_number";
            this.txb_filtro_serial_number.Size = new System.Drawing.Size(173, 45);
            this.txb_filtro_serial_number.TabIndex = 16;
            // 
            // txb_filtro_n_pat
            // 
            this.txb_filtro_n_pat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_n_pat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_n_pat.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_n_pat.Location = new System.Drawing.Point(182, 105);
            this.txb_filtro_n_pat.Multiline = true;
            this.txb_filtro_n_pat.Name = "txb_filtro_n_pat";
            this.txb_filtro_n_pat.Size = new System.Drawing.Size(173, 45);
            this.txb_filtro_n_pat.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(3, 153);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(173, 51);
            this.label9.TabIndex = 18;
            this.label9.Text = "Serial Number";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_filtro
            // 
            this.btn_filtro.BackColor = System.Drawing.Color.Navy;
            this.btn_filtro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_filtro.Location = new System.Drawing.Point(361, 54);
            this.btn_filtro.Name = "btn_filtro";
            this.btn_filtro.Size = new System.Drawing.Size(174, 45);
            this.btn_filtro.TabIndex = 0;
            this.btn_filtro.Text = "Filtrar";
            this.btn_filtro.UseVisualStyleBackColor = false;
            this.btn_filtro.Click += new System.EventHandler(this.btn_filtro_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Navy;
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Gold;
            this.groupBox2.Location = new System.Drawing.Point(553, 393);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(544, 285);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Registrar";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel3.Controls.Add(this.cbb_descricao_grava, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBox4, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.comboBox3, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.txb_grava_sap, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn_registrar, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_marca, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_modelo, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.txb_grava_n_pat, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txb_grava_serial_number, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.lbl_marca, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 8;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(538, 255);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // comboBox4
            // 
            this.comboBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.ForeColor = System.Drawing.Color.Black;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(182, 189);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(173, 24);
            this.comboBox4.TabIndex = 30;
            this.comboBox4.DropDown += new System.EventHandler(this.comboBox4_DropDown);
            // 
            // comboBox3
            // 
            this.comboBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.ForeColor = System.Drawing.Color.Black;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(182, 220);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(173, 24);
            this.comboBox3.TabIndex = 29;
            this.comboBox3.DropDown += new System.EventHandler(this.comboBox3_DropDown);
            // 
            // txb_grava_sap
            // 
            this.txb_grava_sap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_grava_sap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_grava_sap.ForeColor = System.Drawing.Color.Black;
            this.txb_grava_sap.Location = new System.Drawing.Point(182, 158);
            this.txb_grava_sap.Multiline = true;
            this.txb_grava_sap.Name = "txb_grava_sap";
            this.txb_grava_sap.Size = new System.Drawing.Size(173, 25);
            this.txb_grava_sap.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(173, 38);
            this.label16.TabIndex = 27;
            this.label16.Text = "Status";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 186);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(173, 31);
            this.label15.TabIndex = 26;
            this.label15.Text = "Local";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(3, 155);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(173, 31);
            this.label14.TabIndex = 25;
            this.label14.Text = "Código SAP";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 31);
            this.label5.TabIndex = 12;
            this.label5.Text = "Serial Number";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 31);
            this.label4.TabIndex = 11;
            this.label4.Text = "Nº Patrimonio";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 31);
            this.label3.TabIndex = 10;
            this.label3.Text = "Descrição";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 31);
            this.label1.TabIndex = 8;
            this.label1.Text = "Modelo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Navy;
            this.btn_registrar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_registrar.Location = new System.Drawing.Point(361, 34);
            this.btn_registrar.Name = "btn_registrar";
            this.tableLayoutPanel3.SetRowSpan(this.btn_registrar, 6);
            this.btn_registrar.Size = new System.Drawing.Size(174, 180);
            this.btn_registrar.TabIndex = 1;
            this.btn_registrar.Text = "Registrar";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbb_grava_marca
            // 
            this.cbb_grava_marca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_marca.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_marca.FormattingEnabled = true;
            this.cbb_grava_marca.Location = new System.Drawing.Point(182, 3);
            this.cbb_grava_marca.Name = "cbb_grava_marca";
            this.cbb_grava_marca.Size = new System.Drawing.Size(173, 24);
            this.cbb_grava_marca.TabIndex = 2;
            this.cbb_grava_marca.DropDown += new System.EventHandler(this.cbb_grava_marca_DropDown);
            this.cbb_grava_marca.SelectedIndexChanged += new System.EventHandler(this.cbb_grava_marca_SelectedIndexChanged);
            // 
            // cbb_grava_modelo
            // 
            this.cbb_grava_modelo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_modelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_modelo.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_modelo.FormattingEnabled = true;
            this.cbb_grava_modelo.Location = new System.Drawing.Point(182, 34);
            this.cbb_grava_modelo.Name = "cbb_grava_modelo";
            this.cbb_grava_modelo.Size = new System.Drawing.Size(173, 24);
            this.cbb_grava_modelo.TabIndex = 3;
            this.cbb_grava_modelo.DropDown += new System.EventHandler(this.cbb_grava_modelo_DropDown);
            // 
            // txb_grava_n_pat
            // 
            this.txb_grava_n_pat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_grava_n_pat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_grava_n_pat.ForeColor = System.Drawing.Color.Black;
            this.txb_grava_n_pat.Location = new System.Drawing.Point(182, 96);
            this.txb_grava_n_pat.Multiline = true;
            this.txb_grava_n_pat.Name = "txb_grava_n_pat";
            this.txb_grava_n_pat.Size = new System.Drawing.Size(173, 25);
            this.txb_grava_n_pat.TabIndex = 5;
            this.txb_grava_n_pat.TextChanged += new System.EventHandler(this.txb_grava_n_pat_TextChanged);
            // 
            // txb_grava_serial_number
            // 
            this.txb_grava_serial_number.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_grava_serial_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_grava_serial_number.ForeColor = System.Drawing.Color.Black;
            this.txb_grava_serial_number.Location = new System.Drawing.Point(182, 127);
            this.txb_grava_serial_number.Multiline = true;
            this.txb_grava_serial_number.Name = "txb_grava_serial_number";
            this.txb_grava_serial_number.Size = new System.Drawing.Size(173, 25);
            this.txb_grava_serial_number.TabIndex = 6;
            // 
            // lbl_marca
            // 
            this.lbl_marca.AutoSize = true;
            this.lbl_marca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_marca.Location = new System.Drawing.Point(3, 0);
            this.lbl_marca.Name = "lbl_marca";
            this.lbl_marca.Size = new System.Drawing.Size(173, 31);
            this.lbl_marca.TabIndex = 7;
            this.lbl_marca.Text = "Marca";
            this.lbl_marca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Navy;
            this.tableLayoutPanel1.SetColumnSpan(this.label10, 2);
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1094, 50);
            this.label10.TabIndex = 5;
            this.label10.Text = "Equipamentos FESA";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 51);
            this.label2.TabIndex = 28;
            this.label2.Text = "Código Equipamento";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(361, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 45);
            this.button1.TabIndex = 29;
            this.button1.Text = "Filtrar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(361, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(174, 45);
            this.button2.TabIndex = 30;
            this.button2.Text = "Filtrar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Navy;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(361, 156);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(174, 45);
            this.button3.TabIndex = 31;
            this.button3.Text = "Filtrar";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Navy;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(361, 207);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(174, 45);
            this.button4.TabIndex = 32;
            this.button4.Text = "Filtrar";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // cbb_descricao_grava
            // 
            this.cbb_descricao_grava.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_descricao_grava.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_descricao_grava.ForeColor = System.Drawing.Color.Black;
            this.cbb_descricao_grava.FormattingEnabled = true;
            this.cbb_descricao_grava.Location = new System.Drawing.Point(182, 65);
            this.cbb_descricao_grava.Name = "cbb_descricao_grava";
            this.cbb_descricao_grava.Size = new System.Drawing.Size(173, 24);
            this.cbb_descricao_grava.TabIndex = 31;
            this.cbb_descricao_grava.DropDown += new System.EventHandler(this.cbb_descricao_grava_DropDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 681);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListView lv_equipamentos;
        private System.Windows.Forms.Button btn_atualizar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn_filtro;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txb_filtro_descricao;
        private System.Windows.Forms.TextBox txb_filtro_serial_number;
        private System.Windows.Forms.TextBox txb_filtro_n_pat;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbb_grava_marca;
        private System.Windows.Forms.ComboBox cbb_grava_modelo;
        private System.Windows.Forms.TextBox txb_grava_n_pat;
        private System.Windows.Forms.TextBox txb_grava_serial_number;
        private System.Windows.Forms.Label lbl_marca;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txb_filtro_sap;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbb_filtro_cod;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox txb_grava_sap;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbb_descricao_grava;
    }
}

