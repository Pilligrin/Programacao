﻿//Grupo: Gustavo Pelegrino (Dispensado), José Henrique Gomes e Lucas Nascimento Bená 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace testedrop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //definição de variáveis globais dentro do Form1, contudo locais para outros Forms
        SqlConnection conexao;
        SqlCommand comando;
        string instrucao_executa;
        string instrucao_preenche;
        SqlDataAdapter consulta;
        DataTable tabela;
        ListViewItem item_list_view;
        string instrucao_filtro = "SELECT mar.descr_marca 'Marca' , mo.descr_modelo 'Modelo', de.descricao 'Descrição', e.num_patrimonio 'Nº Patr.', e.serialNum 'Serial Number', e.cod_sap 'SAP', l.descr_local 'Locais', st.descr_status 'Status', c.conf_datahora 'Data Conf.'" +
               " FROM equipamentos e " +
               " INNER JOIN marcas_equip mar ON mar.cod_marca = e.cod_marca" +
               " INNER JOIN modelos_equip mo ON mo.cod_modelo = e.cod_modelo" +
               " INNER JOIN descricoes_equip de ON de.cod_descr = e.cod_descr " +
               " INNER JOIN status_equip st ON st.cod_status = e.cod_status " +
               " INNER JOIN locais l ON l.cod_local = e.cod_local " +
               " FULL OUTER JOIN conferencias c ON c.cod_equipamento = e.cod_equipamento " ;

        int n = 8; //Número de colunas necessárias

        //Método para realizar a conexão do SQL com o Visual Studio
        private void conecta()
        {
            try
            {
                //Por favor, altere o data source para alt
                conexao = new SqlConnection("Data source = localhost; initial catalog = master; User ID= sa; Password = 123456;");
            }
            catch {
                MessageBox.Show("Um problema foi encontrado na conexão, verifique o Data source, initial catalog, usuário e senha, por favor. \n Verificar método: conecta");
            }
        }

        //Método para executar um comando SQL
        private void executa()
        {
            try
            { 
                conexao.Open();
                comando = new SqlCommand(instrucao_executa, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
            }
            catch
            {
                MessageBox.Show("Houve um problema no comando a ser executado. \n Verificar método: executa");
            }
        }

        //método para preencher DataTable com a consulta
        private void preenche()
        {
            try
            {
                consulta = new SqlDataAdapter(instrucao_preenche, conexao);
                tabela = new DataTable();
                consulta.Fill(tabela);
            }
            catch
            {
                MessageBox.Show("Houve um problema ao criar o DataTable ou/e a consulta. \n Verificar método: preenche");
            }
        }

        //método para atualizar o ListView (fazer a limpeza, preencher e redimensiona ele), dentro dele há a conexão e consulta também, para evitar repetir todos processos
        private void atualiza()
        {
            try
           {
                //Realiza conexão
                conecta();

                //realiza a consulta
                preenche();

                //realiza a limpeza do listview
                lv_equipamentos.Items.Clear();
                lv_equipamentos.Columns.Clear();

                //Adiciona os titulos das colunas
                for (int i = 0; i <= n; i++)//adiciona todas as colunas necessárias, com títulos
                {
                    lv_equipamentos.Columns.Add(tabela.Columns[i].ColumnName);
                }

                //Adiciona uma nova linha
                foreach (DataRow linha in tabela.Rows)//executa para cada linha uma adição aos itens do listview, com a DaTable
                {
                    item_list_view = new ListViewItem(linha[0].ToString());

                    for (int j = 1; j <= n; j++)//for para colocar todos os elementos dentro do item da list view
                    {
                        item_list_view.SubItems.Add(linha[j].ToString());
                    }
                    lv_equipamentos.Items.Add(item_list_view);//adiciona novo item à list View
                }
                //Auto-ajusta o listview
                lv_equipamentos.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                lv_equipamentos.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
           }
            catch {
                MessageBox.Show("Erro ao atualizar o ListView. \n Verificar método: atualiza.");
                   }

        }

        //Quando for apertado o botão Registra, insere os valores no bnaco de dados
        private void button1_Click(object sender, EventArgs e)
        {
            //Realiza a conexão
            conecta();

            //Instrução do comando pedido, a 1° serve para posição e a 2° para as variáveis
            instrucao_executa = "INSERT INTO equipamentos VALUES({0}, {1}, {2}, {3}, '{4}', {5}, {6}, {7});";
            instrucao_executa = string.Format(instrucao_executa, cbb_grava_marca.SelectedValue, cbb_grava_modelo.SelectedValue,
                cbb_grava_descricao.SelectedValue, txb_grava_n_pat.Text, txb_grava_serial_number.Text,
            txb_sap_grava.Text, cbb_grava_local.SelectedValue, cbb_grava_status.SelectedValue);

            //MessageBox.Show(instrucao_executa);

            //Realiza o comando pedido
            executa();
        }

        //Realiza a atualização da lista
        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            
            //Instrução para a consulta e tabela
            instrucao_preenche = instrucao_filtro;

            //Realiza a atualização, dentro dela tem a conexão e consulta também
            atualiza();
          
        }

        private void btn_filtro_Click(object sender, EventArgs e)
        {
            if (txb_filtro_descricao.Text != "")
            {
                //Instrução para realizar a consulta e tabela
                instrucao_preenche = instrucao_filtro  + " WHERE de.descricao LIKE '%{0}%';";
                instrucao_preenche = string.Format(instrucao_preenche, txb_filtro_descricao.Text);

                //Realiza a conexão, consulta e atualiza
                atualiza();
            }
            else
            {
                MessageBox.Show("Escreva algo na descrição, para filtrar.");
            }
        }

        

        private void cbb_grava_marca_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //método utilizado para preencher o ComboBox respectivo
        //Observação: foi utilizado o System.Windows.Forms.ComboBox para deixar explicito o objeto, se der erro troque para "ComboBox"
        private void edita_cbb(string instrucao, string display, string value, ref System.Windows.Forms.ComboBox obj)
        {
            //realiza a conexão
            conecta();
            //Realiza a consulta e a tabela
            instrucao_preenche = instrucao;
            preenche();
            
            try { 
            //configura o ComboBox respectivo
            obj.DataSource = tabela;
            obj.DisplayMember = display;
            obj.ValueMember = value;
                 }
            catch 
            
            {
                MessageBox.Show("Não foi possível configurar corretamente o ComboBox.\n Verificar o método: edita_cbb");
            }
        }

        
        //Realiza a configuração da ComboBox marca, na aba registrar
        private void cbb_grava_marca_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM marcas_equip;", "descr_marca", "cod_marca", ref cbb_grava_marca);
        }

        //Realiza a configuração da ComboBox modelo, na aba registrar
        private void cbb_grava_modelo_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM modelos_equip;", "descr_modelo", "cod_modelo", ref cbb_grava_modelo);
        }

        private void lv_equipamentos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //Realiza a configuração da ComboBox local, na aba registrar
        private void cbb_grava_local_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT cod_local, descr_local FROM locais;", "descr_local", "cod_local", ref cbb_grava_local);
        }

        //Realiza a configuração da ComboBox local, na aba registrar
        private void cbb_grava_status_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT * FROM status_equip;", "descr_status", "cod_status", ref cbb_grava_status);
        }

        //Método para procurar o código de um equipamento com base no serial number, utilizado para inserir a data nova, contudo não será utilizado nesse projeto
        private int procura_codigo()
        {
            //realiza a conexão
            conecta();
            //Realiza a consulta e a tabela
            instrucao_preenche = "SELECT MAX(cod_equipamento) FROM equipamentos WHERE serialNum LIKE {0};";
            instrucao_preenche = string.Format(instrucao_preenche, txb_filtro_serial_number.Text);
            preenche();
            
            //Atribui a uma variável inteira o valor da primeira linha e primeira coluna da consulta
            int Codigo_Equipamento = int.Parse(tabela.Rows[0][0].ToString());
            return Codigo_Equipamento;
        }

        //Realiza a configuração da ComboBox Cod. Eq., na aba de Filtro
        private void cbb_cod_eq_DropDown(object sender, EventArgs e)
        {
            edita_cbb("SELECT cod_equipamento FROM equipamentos;", "cod_equipamento", "cod_equipamento", ref cbb_cod_eq);
        }

        //Quando o botão é pressionado filtra pelo código do equipamento (tem que ser o valor exato)
        private void btn_filtra_cod_Click(object sender, EventArgs e)
        {
            if (cbb_cod_eq.Text != "")
            {
                //Instrução da Consulta
                //Mostra a posição do Place Holder
                instrucao_preenche = instrucao_filtro + " WHERE e.cod_equipamento = {0};";
                //Mostra as variáveis do Place Holder
                instrucao_preenche = string.Format(instrucao_preenche, cbb_cod_eq.Text);
                //Atualiza o LiistView
                atualiza();

            }
            else
            {
                MessageBox.Show("Seleciona o código do equipamento, para filtrar.");
            }
        }

        //Quando o botão é pressionado filtra pelo n° de patrimonio (tem que ser o valor exato)
        private void btn_filtra_pat_Click(object sender, EventArgs e)
        {
            //Caso não for em branco filtra o dado inserido
            if (txb_filtro_n_pat.Text != "")
            {

                instrucao_preenche = instrucao_filtro + " WHERE e.num_patrimonio = {0};";
                instrucao_preenche = string.Format(instrucao_preenche, txb_filtro_n_pat.Text);
                atualiza();

            }
            else
            {
                MessageBox.Show("Faça o scan/digite o Nº do patrimonio, para filtrar.");
            }
        }

        //Quando o botão é pressionado filtra pelo serial number
        private void tbn_filtra_serial_Click(object sender, EventArgs e)
        {
            //Caso não for em branco filtra o dado inserido
            if (txb_filtro_serial_number.Text != "")
            {

                instrucao_preenche = instrucao_filtro + " WHERE e.serialNum LIKE '%{0}%';";
                instrucao_preenche = string.Format(instrucao_preenche, txb_filtro_serial_number.Text);
                atualiza();

            }
            else
            {
                MessageBox.Show("Digite o Serial Number, para filtrar.");
            }
        }

        //Configura o ComboBox descrição da aba de Registro
        private void cbb_grava_descricao_DropDown(object sender, EventArgs e)
        {
            edita_cbb("Select * From descricoes_equip;", "descricao", "cod_descr", ref cbb_grava_descricao);
        }
    }
}
