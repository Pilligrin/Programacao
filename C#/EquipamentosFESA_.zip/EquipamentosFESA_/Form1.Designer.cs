﻿namespace testedrop
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lv_equipamentos = new System.Windows.Forms.ListView();
            this.btn_atualizar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_filtra_pat = new System.Windows.Forms.Button();
            this.tbn_filtra_serial = new System.Windows.Forms.Button();
            this.cbb_cod_eq = new System.Windows.Forms.ComboBox();
            this.btn_filtra_cod = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_filtro_descricao = new System.Windows.Forms.TextBox();
            this.txb_filtro_serial_number = new System.Windows.Forms.TextBox();
            this.txb_filtro_n_pat = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_filtra_desc = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.cbb_grava_local = new System.Windows.Forms.ComboBox();
            this.cbb_grava_status = new System.Windows.Forms.ComboBox();
            this.txb_sap_grava = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.cbb_grava_marca = new System.Windows.Forms.ComboBox();
            this.cbb_grava_modelo = new System.Windows.Forms.ComboBox();
            this.txb_grava_n_pat = new System.Windows.Forms.TextBox();
            this.txb_grava_serial_number = new System.Windows.Forms.TextBox();
            this.lbl_marca = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbb_grava_descricao = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lv_equipamentos, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_atualizar, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1186, 735);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lv_equipamentos
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.lv_equipamentos, 2);
            this.lv_equipamentos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_equipamentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lv_equipamentos.ForeColor = System.Drawing.Color.Black;
            this.lv_equipamentos.HideSelection = false;
            this.lv_equipamentos.Location = new System.Drawing.Point(3, 53);
            this.lv_equipamentos.Name = "lv_equipamentos";
            this.lv_equipamentos.Size = new System.Drawing.Size(1180, 311);
            this.lv_equipamentos.TabIndex = 0;
            this.lv_equipamentos.UseCompatibleStateImageBehavior = false;
            this.lv_equipamentos.View = System.Windows.Forms.View.Details;
            this.lv_equipamentos.SelectedIndexChanged += new System.EventHandler(this.lv_equipamentos_SelectedIndexChanged);
            // 
            // btn_atualizar
            // 
            this.btn_atualizar.BackColor = System.Drawing.Color.DarkBlue;
            this.tableLayoutPanel1.SetColumnSpan(this.btn_atualizar, 2);
            this.btn_atualizar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_atualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_atualizar.ForeColor = System.Drawing.Color.Gold;
            this.btn_atualizar.Location = new System.Drawing.Point(3, 370);
            this.btn_atualizar.Name = "btn_atualizar";
            this.btn_atualizar.Size = new System.Drawing.Size(1180, 44);
            this.btn_atualizar.TabIndex = 1;
            this.btn_atualizar.Text = "Atualizar Lista";
            this.btn_atualizar.UseVisualStyleBackColor = false;
            this.btn_atualizar.Click += new System.EventHandler(this.btn_atualizar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Navy;
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Gold;
            this.groupBox1.Location = new System.Drawing.Point(3, 420);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(587, 312);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtro";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel2.Controls.Add(this.btn_filtra_pat, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.tbn_filtra_serial, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.cbb_cod_eq, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn_filtra_cod, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_descricao, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_serial_number, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txb_filtro_n_pat, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn_filtra_desc, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(581, 282);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btn_filtra_pat
            // 
            this.btn_filtra_pat.BackColor = System.Drawing.Color.Navy;
            this.btn_filtra_pat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_filtra_pat.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filtra_pat.Location = new System.Drawing.Point(389, 143);
            this.btn_filtra_pat.Name = "btn_filtra_pat";
            this.btn_filtra_pat.Size = new System.Drawing.Size(189, 64);
            this.btn_filtra_pat.TabIndex = 33;
            this.btn_filtra_pat.Text = "Filtrar";
            this.btn_filtra_pat.UseVisualStyleBackColor = false;
            this.btn_filtra_pat.Click += new System.EventHandler(this.btn_filtra_pat_Click);
            // 
            // tbn_filtra_serial
            // 
            this.tbn_filtra_serial.BackColor = System.Drawing.Color.Navy;
            this.tbn_filtra_serial.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbn_filtra_serial.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbn_filtra_serial.Location = new System.Drawing.Point(389, 213);
            this.tbn_filtra_serial.Name = "tbn_filtra_serial";
            this.tbn_filtra_serial.Size = new System.Drawing.Size(189, 66);
            this.tbn_filtra_serial.TabIndex = 32;
            this.tbn_filtra_serial.Text = "Filtrar";
            this.tbn_filtra_serial.UseVisualStyleBackColor = false;
            this.tbn_filtra_serial.Click += new System.EventHandler(this.tbn_filtra_serial_Click);
            // 
            // cbb_cod_eq
            // 
            this.cbb_cod_eq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbb_cod_eq.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_cod_eq.ForeColor = System.Drawing.Color.Black;
            this.cbb_cod_eq.FormattingEnabled = true;
            this.cbb_cod_eq.Location = new System.Drawing.Point(196, 21);
            this.cbb_cod_eq.Name = "cbb_cod_eq";
            this.cbb_cod_eq.Size = new System.Drawing.Size(187, 28);
            this.cbb_cod_eq.TabIndex = 30;
            this.cbb_cod_eq.DropDown += new System.EventHandler(this.cbb_cod_eq_DropDown);
            // 
            // btn_filtra_cod
            // 
            this.btn_filtra_cod.BackColor = System.Drawing.Color.Navy;
            this.btn_filtra_cod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_filtra_cod.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filtra_cod.Location = new System.Drawing.Point(389, 3);
            this.btn_filtra_cod.Name = "btn_filtra_cod";
            this.btn_filtra_cod.Size = new System.Drawing.Size(189, 64);
            this.btn_filtra_cod.TabIndex = 29;
            this.btn_filtra_cod.Text = "Filtrar";
            this.btn_filtra_cod.UseVisualStyleBackColor = false;
            this.btn_filtra_cod.Click += new System.EventHandler(this.btn_filtra_cod_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(187, 70);
            this.label11.TabIndex = 27;
            this.label11.Text = "Código Eq.";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 70);
            this.label6.TabIndex = 21;
            this.label6.Text = "Nº Patrimonio";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(187, 70);
            this.label7.TabIndex = 20;
            this.label7.Text = "Descrição";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txb_filtro_descricao
            // 
            this.txb_filtro_descricao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_descricao.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_descricao.Location = new System.Drawing.Point(196, 73);
            this.txb_filtro_descricao.Multiline = true;
            this.txb_filtro_descricao.Name = "txb_filtro_descricao";
            this.txb_filtro_descricao.Size = new System.Drawing.Size(187, 64);
            this.txb_filtro_descricao.TabIndex = 15;
            // 
            // txb_filtro_serial_number
            // 
            this.txb_filtro_serial_number.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_serial_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_serial_number.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_serial_number.Location = new System.Drawing.Point(196, 213);
            this.txb_filtro_serial_number.Multiline = true;
            this.txb_filtro_serial_number.Name = "txb_filtro_serial_number";
            this.txb_filtro_serial_number.Size = new System.Drawing.Size(187, 66);
            this.txb_filtro_serial_number.TabIndex = 16;
            // 
            // txb_filtro_n_pat
            // 
            this.txb_filtro_n_pat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_filtro_n_pat.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_filtro_n_pat.ForeColor = System.Drawing.Color.Black;
            this.txb_filtro_n_pat.Location = new System.Drawing.Point(196, 143);
            this.txb_filtro_n_pat.Multiline = true;
            this.txb_filtro_n_pat.Name = "txb_filtro_n_pat";
            this.txb_filtro_n_pat.Size = new System.Drawing.Size(187, 64);
            this.txb_filtro_n_pat.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(3, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 72);
            this.label9.TabIndex = 18;
            this.label9.Text = "Serial Number";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_filtra_desc
            // 
            this.btn_filtra_desc.BackColor = System.Drawing.Color.Navy;
            this.btn_filtra_desc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_filtra_desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filtra_desc.Location = new System.Drawing.Point(389, 73);
            this.btn_filtra_desc.Name = "btn_filtra_desc";
            this.btn_filtra_desc.Size = new System.Drawing.Size(189, 64);
            this.btn_filtra_desc.TabIndex = 0;
            this.btn_filtra_desc.Text = "Filtrar";
            this.btn_filtra_desc.UseVisualStyleBackColor = false;
            this.btn_filtra_desc.Click += new System.EventHandler(this.btn_filtro_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Navy;
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Gold;
            this.groupBox2.Location = new System.Drawing.Point(596, 420);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(587, 312);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Registrar";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_descricao, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_local, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_status, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.txb_sap_grava, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn_registrar, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_marca, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.cbb_grava_modelo, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.txb_grava_n_pat, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.txb_grava_serial_number, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.lbl_marca, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 27);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 8;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(581, 282);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // cbb_grava_local
            // 
            this.cbb_grava_local.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_local.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_local.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_local.FormattingEnabled = true;
            this.cbb_grava_local.Location = new System.Drawing.Point(196, 213);
            this.cbb_grava_local.Name = "cbb_grava_local";
            this.cbb_grava_local.Size = new System.Drawing.Size(187, 24);
            this.cbb_grava_local.TabIndex = 30;
            this.cbb_grava_local.DropDown += new System.EventHandler(this.cbb_grava_local_DropDown);
            // 
            // cbb_grava_status
            // 
            this.cbb_grava_status.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_status.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_status.FormattingEnabled = true;
            this.cbb_grava_status.Location = new System.Drawing.Point(196, 248);
            this.cbb_grava_status.Name = "cbb_grava_status";
            this.cbb_grava_status.Size = new System.Drawing.Size(187, 24);
            this.cbb_grava_status.TabIndex = 29;
            this.cbb_grava_status.DropDown += new System.EventHandler(this.cbb_grava_status_DropDown);
            // 
            // txb_sap_grava
            // 
            this.txb_sap_grava.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_sap_grava.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_sap_grava.ForeColor = System.Drawing.Color.Black;
            this.txb_sap_grava.Location = new System.Drawing.Point(196, 178);
            this.txb_sap_grava.Multiline = true;
            this.txb_sap_grava.Name = "txb_sap_grava";
            this.txb_sap_grava.Size = new System.Drawing.Size(187, 29);
            this.txb_sap_grava.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 245);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(187, 37);
            this.label16.TabIndex = 27;
            this.label16.Text = "Status";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 210);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(187, 35);
            this.label15.TabIndex = 26;
            this.label15.Text = "Local";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(3, 175);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(187, 35);
            this.label14.TabIndex = 25;
            this.label14.Text = "Código SAP";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(187, 35);
            this.label5.TabIndex = 12;
            this.label5.Text = "Serial Number";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(187, 35);
            this.label4.TabIndex = 11;
            this.label4.Text = "Nº Patrimonio";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 35);
            this.label3.TabIndex = 10;
            this.label3.Text = "Descrição";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 35);
            this.label1.TabIndex = 8;
            this.label1.Text = "Modelo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Navy;
            this.btn_registrar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_registrar.Location = new System.Drawing.Point(389, 38);
            this.btn_registrar.Name = "btn_registrar";
            this.tableLayoutPanel3.SetRowSpan(this.btn_registrar, 6);
            this.btn_registrar.Size = new System.Drawing.Size(189, 204);
            this.btn_registrar.TabIndex = 1;
            this.btn_registrar.Text = "Registrar";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbb_grava_marca
            // 
            this.cbb_grava_marca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_marca.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_marca.FormattingEnabled = true;
            this.cbb_grava_marca.Location = new System.Drawing.Point(196, 3);
            this.cbb_grava_marca.Name = "cbb_grava_marca";
            this.cbb_grava_marca.Size = new System.Drawing.Size(187, 24);
            this.cbb_grava_marca.TabIndex = 2;
            this.cbb_grava_marca.DropDown += new System.EventHandler(this.cbb_grava_marca_DropDown);
            this.cbb_grava_marca.SelectedIndexChanged += new System.EventHandler(this.cbb_grava_marca_SelectedIndexChanged);
            // 
            // cbb_grava_modelo
            // 
            this.cbb_grava_modelo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_modelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_modelo.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_modelo.FormattingEnabled = true;
            this.cbb_grava_modelo.Location = new System.Drawing.Point(196, 38);
            this.cbb_grava_modelo.Name = "cbb_grava_modelo";
            this.cbb_grava_modelo.Size = new System.Drawing.Size(187, 24);
            this.cbb_grava_modelo.TabIndex = 3;
            this.cbb_grava_modelo.DropDown += new System.EventHandler(this.cbb_grava_modelo_DropDown);
            // 
            // txb_grava_n_pat
            // 
            this.txb_grava_n_pat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_grava_n_pat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_grava_n_pat.ForeColor = System.Drawing.Color.Black;
            this.txb_grava_n_pat.Location = new System.Drawing.Point(196, 108);
            this.txb_grava_n_pat.Multiline = true;
            this.txb_grava_n_pat.Name = "txb_grava_n_pat";
            this.txb_grava_n_pat.Size = new System.Drawing.Size(187, 29);
            this.txb_grava_n_pat.TabIndex = 5;
            // 
            // txb_grava_serial_number
            // 
            this.txb_grava_serial_number.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_grava_serial_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_grava_serial_number.ForeColor = System.Drawing.Color.Black;
            this.txb_grava_serial_number.Location = new System.Drawing.Point(196, 143);
            this.txb_grava_serial_number.Multiline = true;
            this.txb_grava_serial_number.Name = "txb_grava_serial_number";
            this.txb_grava_serial_number.Size = new System.Drawing.Size(187, 29);
            this.txb_grava_serial_number.TabIndex = 6;
            // 
            // lbl_marca
            // 
            this.lbl_marca.AutoSize = true;
            this.lbl_marca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_marca.Location = new System.Drawing.Point(3, 0);
            this.lbl_marca.Name = "lbl_marca";
            this.lbl_marca.Size = new System.Drawing.Size(187, 35);
            this.lbl_marca.TabIndex = 7;
            this.lbl_marca.Text = "Marca";
            this.lbl_marca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Navy;
            this.tableLayoutPanel1.SetColumnSpan(this.label10, 2);
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1180, 50);
            this.label10.TabIndex = 5;
            this.label10.Text = "Equipamentos FESA";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbb_grava_descricao
            // 
            this.cbb_grava_descricao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbb_grava_descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_grava_descricao.ForeColor = System.Drawing.Color.Black;
            this.cbb_grava_descricao.FormattingEnabled = true;
            this.cbb_grava_descricao.Location = new System.Drawing.Point(196, 73);
            this.cbb_grava_descricao.Name = "cbb_grava_descricao";
            this.cbb_grava_descricao.Size = new System.Drawing.Size(187, 24);
            this.cbb_grava_descricao.TabIndex = 31;
            this.cbb_grava_descricao.DropDown += new System.EventHandler(this.cbb_grava_descricao_DropDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1186, 735);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListView lv_equipamentos;
        private System.Windows.Forms.Button btn_atualizar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn_filtra_desc;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txb_filtro_descricao;
        private System.Windows.Forms.TextBox txb_filtro_serial_number;
        private System.Windows.Forms.TextBox txb_filtro_n_pat;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbb_grava_marca;
        private System.Windows.Forms.ComboBox cbb_grava_modelo;
        private System.Windows.Forms.TextBox txb_grava_n_pat;
        private System.Windows.Forms.TextBox txb_grava_serial_number;
        private System.Windows.Forms.Label lbl_marca;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbb_grava_local;
        private System.Windows.Forms.ComboBox cbb_grava_status;
        private System.Windows.Forms.TextBox txb_sap_grava;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btn_filtra_cod;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbb_cod_eq;
        private System.Windows.Forms.Button tbn_filtra_serial;
        private System.Windows.Forms.Button btn_filtra_pat;
        private System.Windows.Forms.ComboBox cbb_grava_descricao;
    }
}

