﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exemplos_Placeholder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void teste_strings()
        {
            char um_caractere = 'A';
            string texto = "Marco Aurélio";
            int numero;
            double numero_decimal;

            texto = texto + " Vinchi"; //Concatena o texto com um novo trecho
            texto = "O valor de pi é de ";
            texto = texto + Math.PI;//Ocorre uma conversão implícita de um tipo double para string
            numero = Convert.ToInt16(Math.PI);//Ocorre uma conversão explícita de uma double para int
            numero_decimal = 2;
            lbl_teste.Text = texto;
            //Placeholder - Ponto de referência de inserção de dados em uma string
            texto = "O valor de pi é de " + 
                    Math.PI + 
                    " e é a razão entre o perímetro e o diâmetro de um círculo.";
            lbl_teste.Text = texto;
            texto = "O valor de pi é de " +
                    Math.PI.ToString("F3") + //Código "F3" trata a variável como ponto flutuante com três casas decimais
                    " e é a razão entre o perímetro e o diâmetro de um círculo.";
            lbl_teste.Text = texto;
            texto = string.Format("O {2:X} valor de pi é {0:F3} e é a razão {1:C} entre{3} o pe...",
                                  Math.PI, 213.463256, 23, "Texto");
            lbl_teste.Text = texto;
            string mostrar = "{0}\n\n\n\n\n\a{1}";
            string mostar_2 = @"\W\n";//Atribui um texto sem qualquer codificação
            texto = string.Format(mostrar, Math.PI, Math.Pow(Math.PI, 2));
            lbl_teste.Text = texto;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            teste_strings();
        }
    }
}
